#include "project.h"

void handleU(Context *context){
  char *buffer = context->buffer;
  char licence[9] = {0};
  int i;
  Park *park;
  Event *event;
  float total = 0;
  sscanf(buffer, "%*c %8s", licence);
  if(!validateLicence(licence)) {
    printf("%s: invalid licence plate.\n", licence);
    return;
  }
  for(i = 0; i<MAX_PARKS;i++) {
    park = context->parks_array[i];
    if(!park)
      break;
    event = park->event_list.head;
    while(event != NULL) {
      if(strcmp(licence, event->licence) == 0 && event->type == 's'){
        total += event->bill;
      }
      event = event->next;
    }
  }
  printf("%.2f\n", total);
}
